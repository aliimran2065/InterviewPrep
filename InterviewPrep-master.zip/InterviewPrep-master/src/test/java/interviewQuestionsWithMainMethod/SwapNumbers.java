package interviewQuestionsWithMainMethod;

public class SwapNumbers {

	public static void main(String[] args) {
		int a = 5;
		int b = 7;

		int temp;

		temp = a;
		a = b;
		b = temp;
		
		System.out.println(a + " "+ b);

		System.out.println(a);
		System.out.println(b);

	}


}
