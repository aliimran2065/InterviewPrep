package interviewQuestionsWithMainMethod;

import java.util.Scanner;

public class PalindromeOrNot {

	public static void main(String[] args) {
		
		System.out.println("Give me a String!");
		Scanner in = new Scanner(System.in);
		String userGivenString = in.nextLine();
		char[] userCharArray = userGivenString.toCharArray();
		String reversedString = "";

		for (int i = userGivenString.length() - 1; i >= 0; i--) {
			reversedString = reversedString + userCharArray[i];
		}
		// System.out.println("ReversedString: " + reversedString);

		if (userGivenString.equalsIgnoreCase(reversedString)) {
			System.out.println("Given string is : Palindrome"); 
		} else {
			System.out.println("Given string is : not a Palindrome!");
		}
		in.close();
	}
	

}
